# Moka7 OFFICIAL

This is the **official** Moka7 repository starting with release 1.0.3.

Previous releases are available in the <a href="https://sourceforge.net/projects/snap7/files/Moka7/" target="_blank">SourceForge</a> repository.

The official site is still <a href="https://snap7.sourceforge.net/" target="_blank">here</a>.

---

for convenience the source files are included into two projects both containing also a demo program.

- A NetBeans 4.7 project called **Moka7-NetBeans**.
- A Eclipse Kepler project called **Moka7-Eclipse**.

The projects are ABSOLUTLY THE SAME and contain the SAME SOURCE FILES.

Use the one that you like.

Moka7 starting from 1.0.2 is released under dual license : LGPL3 and EPL 1.0

The EPL and the GPL are not compatible, so you have to choose in advance which take before you import the library into your project.

